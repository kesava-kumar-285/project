import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Movies } from './movies';
@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {
  errorMsg : string;

  Movies:any = [];
  movie:Movies;
  name:any;
  cust_name:any;
  flag: boolean = true;
  id:any;
  p: number=1;
  propertyName;

  constructor(private httpClient:HttpClient) { }

 


  ngOnInit(): void {
    this.httpClient.get("assets/data/movies.json").
  subscribe(data =>
    {
      console.log(data);
      this.Movies = data;
    },
    (error)=>
    {
      console.log("error has occured");
      this.errorMsg = error.message;
      alert(this.errorMsg);
    });
  } 

  onOptionsSelected(value:string) {
    if(value != "select"){
      for(var i=0;i<=this.Movies.length;i++){
        if(this.Movies[i].name == value){
          break;
        }
      }
      this.flag=false;
      this.movie = this.Movies[i];
    }
    else{
      this.flag = true;
    }
  }






  Search(){
    if(this.name == ""){
      this.ngOnInit();
    }else{
      this.Movies = this.Movies.filter(res=>{
        return res.name.toLocaleLowerCase().match(this.name.toLocaleLowerCase());
      })
    }
  }
  Search1(){
    if(this.id == ""){
      this.ngOnInit();
    }else{
      this.Movies = this.Movies.filter(res=>{
        return res.id.match(this.id);
      })
    }
  }

  key:string ='id';
  reverse: boolean =false;
  sort(key){
    this.key=key;
    this.reverse=!this.reverse;
  }
































  
}
